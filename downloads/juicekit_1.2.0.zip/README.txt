Welcome to JuiceKit


# Contents

juicekit_{VERSION}.swc

	A compiled library containing JuiceKit.
	
	For most Flex projects, you will put the juicekit.swc file
	in the /libs directory in your project.

/docs/

	The asdocs generated from the JuiceKit source code.

/sources/

	The source code and assets required to build JuiceKit. To build JuiceKit
	from source, all of the directories need to be included in a Flex library 
	project.

/sources/libs/
		
	Contains US map asset files required to use the DMAMapControl and 
	USMapControl components.
	
/sources/shared/

	Contains shared ActionScript code that is included in JuiceKit components.
	
/sources/src/

	Contains the source code.
	